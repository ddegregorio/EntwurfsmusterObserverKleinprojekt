package com.company;

import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;

import java.util.ArrayList;
import java.util.List;

public class ObservableListDemo {

    public static void main(String[] args)
    {
        List<Artikel> artikelSammlung = new ArrayList<Artikel>();
        ObservableList<Artikel> observableList = FXCollections.observableList(artikelSammlung);

        observableList.add(new Artikel("Sachertorte"));
        observableList.add(new Artikel("Whiskey torte"));

        User u1 = new User("Wolfgang");
        User u2 = new User("Thomas");

        observableList.addListener(u1);
        observableList.addListener(u2);


        observableList.add(new Artikel("Dobos torte"));
    }

}
