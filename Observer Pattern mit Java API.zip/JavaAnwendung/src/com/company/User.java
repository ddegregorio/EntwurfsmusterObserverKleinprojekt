package com.company;

import javafx.collections.ListChangeListener;

public class User implements ListChangeListener{
    private String username;

    public User(String username){
        this.username = username;
    }

    @Override
    public void onChanged(Change c) {
        while (c.next()) {

            if(c.wasAdded()){
                System.out.println("Hey user "+ username + "!\n" +
                        "Schau mal wieder vorbeit! Wir haben neue Artikel " +
                        "auf unserer Homepage!\n");
            }

        }



    }
}
