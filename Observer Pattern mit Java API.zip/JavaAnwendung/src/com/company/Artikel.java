package com.company;

public class Artikel {
    private String nameDerTorte;

    public Artikel(String nameDerTorte)
    {
        this.nameDerTorte = nameDerTorte;
    }
}
